
    // $(document).ready(function(){
    // getAccordion("#tabs",768);
    // });